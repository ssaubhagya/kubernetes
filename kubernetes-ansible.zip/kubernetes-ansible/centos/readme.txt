
cd kubernetes-ansible/centos
ansible-playbook -i hosts setup_master_node.yml --extra-vars "ansible_sudo_pass=Wns@dm1n"

Modify ansible.cfg

Uncomment host_key_checking = False